package hw.lifemaker;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class PointBreakdown extends AppCompatActivity {

    public int[] INT; //array[passionNumber]
    public int[] STR;
    public int[] PRS;
    public int[] AGI;
    public int TINT; //Total stat value
    public int TSTR;
    public int TPRS;
    public int TAGI;
    public String result;
    public boolean isAlive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_point_breakdown);
        Intent intent = getIntent();
        TextView pas1 = (TextView)findViewById(R.id.pas1);
        pas1.setText(intent.getStringExtra("passion1"));
        TextView pas2 = (TextView)findViewById(R.id.pas2);
        pas2.setText(intent.getStringExtra("passion2"));
        TextView pas3 = (TextView)findViewById(R.id.pas3);
        pas3.setText(intent.getStringExtra("passion3"));
        result = intent.getStringExtra("result");
        TINT = intent.getIntExtra("TINT", 0);
        TSTR = intent.getIntExtra("TSTR", 0);
        TPRS = intent.getIntExtra("TPRS", 0);
        TAGI = intent.getIntExtra("TAGI", 0);
        INT = intent.getIntArrayExtra("INT");
        STR = intent.getIntArrayExtra("STR");
        PRS = intent.getIntArrayExtra("PRS");
        AGI = intent.getIntArrayExtra("AGI");
        isAlive = intent.getBooleanExtra("isAlive", true);
        TextView stat1 = (TextView)findViewById(R.id.stat1);
        stat1.setText("INT +"+INT[0]);
        TextView stat2 = (TextView)findViewById(R.id.stat2);
        stat2.setText("STR +"+STR[0]);
        TextView stat3 = (TextView)findViewById(R.id.stat3);
        stat3.setText("PRS +"+PRS[0]);
        TextView stat4 = (TextView)findViewById(R.id.stat4);
        stat4.setText("AGI +"+AGI[0]);
        TextView stat5 = (TextView)findViewById(R.id.stat5);
        stat5.setText("INT +"+INT[1]);
        TextView stat6 = (TextView)findViewById(R.id.stat6);
        stat6.setText("STR +"+STR[1]);
        TextView stat7 = (TextView)findViewById(R.id.stat7);
        stat7.setText("PRS +"+PRS[1]);
        TextView stat8 = (TextView)findViewById(R.id.stat8);
        stat8.setText("AGI +"+AGI[1]);
        TextView stat9 = (TextView)findViewById(R.id.stat9);
        stat9.setText("INT +"+INT[2]);
        TextView stat10 = (TextView)findViewById(R.id.stat10);
        stat10.setText("STR +"+STR[2]);
        TextView stat11 = (TextView)findViewById(R.id.stat11);
        stat11.setText("PRS +"+PRS[2]);
        TextView stat12 = (TextView)findViewById(R.id.stat12);
        stat12.setText("AGI +"+AGI[2]);
    }

    public void sendMessage(View view){
        Intent intent = new Intent(this, GameScreen.class);
        intent.putExtra("TINT", TINT);
        intent.putExtra("TSTR", TSTR);
        intent.putExtra("TPRS", TPRS);
        intent.putExtra("TAGI", TAGI);
        intent.putExtra("result", result);
        intent.putExtra("isAlive", isAlive);
        startActivity(intent);
    }
}
