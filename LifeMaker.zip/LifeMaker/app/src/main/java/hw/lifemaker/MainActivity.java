package hw.lifemaker;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {

    boolean activateButton = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public int[] INT = new int[3]; //array[passionNumber]
    public int[] STR = new int[3];
    public int[] PRS = new int[3];
    public int[] AGI = new int[3];
    public int TINT = 0; //Total Stat
    public int TSTR = 0;
    public int TPRS = 0;
    public int TAGI = 0;
    boolean isAlive = true;
    public String result = "";
    public String passion1 = "";
    public String passion2 = "";
    public String passion3 = "";
    public String act1 = "";
    public String nameGenerator(){
        String name = "";
        int rollName = (int)(104*Math.random());
        name = switchName(rollName);
        return name;
    }
    public String switchName(int k){
        String name = "";
        switch (k) {
            case 0:
                name = "James";
                break;
            case 1:
                name = "Mary";
                break;
            case 2:
                name = "John";
                break;
            case 3:
                name = "Patricia";
                break;
            case 4:
                name = "Robert";
                break;
            case 5:
                name = "Linda";
                break;
            case 6:
                name = "Michael";
                break;
            case 7:
                name = "Barbara";
                break;
            case 8:
                name = "William";
                break;
            case 9:
                name = "Elizabeth";
                break;
            case 10:
                name = "David";
                break;
            case 11:
                name = "Jennifer";
                break;
            case 12:
                name = "Richard";
                break;
            case 13:
                name = "Maria";
                break;
            case 14:
                name = "Charles";
                break;
            case 15:
                name = "Susan";
                break;
            case 16:
                name = "Joseph";
                break;
            case 17:
                name = "Margaret";
                break;
            case 18:
                name = "Thomas";
                break;
            case 19:
                name = "Dorothy";
                break;
            case 20:
                name = "Myrtle";
                break;
            case 21:
                name = "Deborah";
                break;
            case 22:
                name = "Joshua";
                break;
            case 23:
                name = "Meredith";
                break;
            case 24:
                name = "Dwight";
                break;
            case 25:
                name = "Jim";
                break;
            case 26:
                name = "Luke";
                break;
            case 27:
                name = "Paul";
                break;
            case 28:
                name = "Mark";
                break;
            case 29:
                name = "Matthew";
                break;
            case 30:
                name = "Donald";
                break;
            case 31:
                name = "Hillary";
                break;
            case 32:
                name = "Miley";
                break;
            case 33:
                name = "Sandra";
                break;
            case 34:
                name = "Carol";
                break;
            case 35:
                name = "Ruth";
                break;
            case 36:
                name = "Jimothy";
                break;
            case 37:
                name = "George";
                break;
            case 38:
                name = "Kevin";
                break;
            case 39:
                name = "Shirley";
                break;
            case 40:
                name = "Larry";
                break;
            case 41:
                name = "Ronald";
                break;
            case 42:
                name = "Jose";
                break;
            case 43:
                name = "Gary";
                break;
            case 44:
                name = "Jerry";
                break;
            case 45:
                name = "Franklin";
                break;
            case 46:
                name = "Jason";
                break;
            case 47:
                name = "Martha";
                break;
            case 48:
                name = "Debra";
                break;
            case 49:
                name = "Gregory";
                break;
            case 50:
                name = "Raymond";
                break;
            case 51:
                name = "Janet";
                break;
            case 52:
                name = "Harold";
                break;
            case 53:
                name = "Henry";
                break;
            case 54:
                name = "Carl";
                break;
            case 55:
                name = "Joyce";
                break;
            case 56:
                name = "Roger";
                break;
            case 57:
                name = "Diane";
                break;
            case 58:
                name = "Wayne";
                break;
            case 59:
                name = "Irene";
                break;
            case 60:
                name = "Irma";
                break;
            case 61:
                name = "Harvey";
                break;
            case 62:
                name = "Rita";
                break;
            case 63:
                name = "Dale";
                break;
            case 64:
                name = "Rodney";
                break;
            case 65:
                name = "Gladys";
                break;
            case 66:
                name = "Satan";
                break;
            case 67:
                name = "Lucifer";
                break;
            case 68:
                name = "Florence";
                break;
            case 69:
                name = "Tracey";
                break;
            case 70:
                name = "Nathan";
                break;
            case 71:
                name = "Kurtis";
                break;
            case 72:
                name = "Jacob";
                break;
            case 73:
                name = "Peter";
                break;
            case 74:
                name = "Parker";
                break;
            case 75:
                name = "Sam";
                break;
            case 76:
                name = "Dawn";
                break;
            case 77:
                name = "Carmen";
                break;
            case 78:
                name = "Leonard";
                break;
            case 79:
                name = "Chad";
                break;
            case 80:
                name = "Harrison";
                break;
            case 81:
                name = "Juanita";
                break;
            case 82:
                name = "Roberto";
                break;
            case 83:
                name = "Rhonda";
                break;
            case 84:
                name = "Jesus";
                break;
            case 85:
                name = "Ray";
                break;
            case 86:
                name = "Zachary";
                break;
            case 87:
                name = "Yvonne";
                break;
            case 88:
                name = "Gordon";
                break;
            case 89:
                name = "Cthulhu";
                break;
            case 90:
                name = "Stacey";
                break;
            case 91:
                name = "Miguel";
                break;
            case 92:
                name = "Agnes";
                break;
            case 93:
                name = "Francisco";
                break;
            case 94:
                name = "Bessie";
                break;
            case 95:
                name = "McCree";
                break;
            case 96:
                name = "Eileen";
                break;
            case 97:
                name = "Gabe";
                break;
            case 98:
                name = "Raul";
                break;
            case 99:
                name = "Cory";
                break;
            case 100:
                name = "Jared";
                break;
            case 101:
                name = "Lance";
                break;
            case 102:
                name = "Leia";
                break;
            case 103:
                name = "Nellie";
                break;
            default:
                name = "";
        }
        return name;
    }

    public String ssnGenerator() {
        int ssn1 = (int) (999 * Math.random() + 1);
        String ssn1S = String.format("%03d", ssn1);
        int ssn2 = (int) (99 * Math.random() + 1);
        String ssn2S = String.format("%02d", ssn2);
        int ssn3 = (int) (9999 * Math.random() + 1);
        String ssn3S = String.format("%04d", ssn3);
        String wholessn = ssn1S + "-" + ssn2S + "-" + ssn3S;
        return wholessn;
    }

    public String passionGenerator(int number) {
        String passion;
        int roll;
        roll = (int)(216*Math.random()+1);
        passion = switchResult(number, roll);
        return passion;
    }


    public String switchResult(int number, int randomNum) {
        String passion = "";
        switch (randomNum) {
            case 1:
                passion = "nothing. You have no Passions.";
                INT[number] = 0;
                STR[number] = 0;
                PRS[number] = 0;
                AGI[number] = 0;
                break;
            case 2:
                passion = "death";
                INT[number] = 0;
                STR[number] = 0;
                PRS[number] = 0;
                AGI[number] = 0;
                break;
            case 3:
                passion = "dying";
                INT[number] = 0;
                STR[number] = 0;
                PRS[number] = 0;
                AGI[number] = 0;
                break;
            case 4:
                passion = "ending your life";
                INT[number] = 0;
                STR[number] = 0;
                PRS[number] = 0;
                AGI[number] = 0;
                break;
            case 5:
                passion = "killing Nazis";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 6:
                passion = "climbing mountains";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 7:
                passion = "meeting extraterrestrials";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 8:
                passion = "rigging elections";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 9:
                passion = "being alive";
                INT[number] = (int)(4*Math.random()+2);
                STR[number] = (int)(4*Math.random()+2);
                PRS[number] = (int)(4*Math.random()+2);
                AGI[number] = (int)(4*Math.random()+2);
                break;
            case 10:
                passion = "playing video games";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 1;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 1;
                break;
            case 11:
                passion = "jogging";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 12:
                passion = "making money";
                INT[number] = (int)(3*Math.random()+3);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 13:
                passion = "eating";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(3*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 1;
                break;
            case 14:
                passion = "meeting new people";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 15:
                passion = "playing with animals";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(3*Math.random()+3);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 16:
                passion = "riding horses";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 17:
                passion = "birdwatching";
                INT[number] = (int)(3*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 1;
                break;
            case 18:
                passion = "UFO hunting";
                INT[number] = 1;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 1;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 19:
                passion = "making friends";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 20:
                passion = "making enemies";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 0;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 21:
                passion = "watching Netflix";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 2;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 1;
                break;
            case 22:
                passion = "the environment";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 23:
                passion = "French culture";
                INT[number] = -5;
                STR[number] = -5;
                PRS[number] = -5;
                AGI[number] = -5;
                break;
            case 24:
                passion = "Japanese culture";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 25:
                passion = "chasing the UPS man";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 26:
                passion = "cinema";
                INT[number] = (int)(3*Math.random()+3);
                STR[number] = (int)(4*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(4*Math.random()+1);
                break;
            case 27:
                passion = "magic";
                INT[number] = 5;
                STR[number] = (int)(3*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(3*Math.random()+1);
                break;
            case 28:
                passion = "genocide";
                INT[number] = (int)(2*Math.random()+1);
                STR[number] = 5;
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 29:
                passion = "religious ecumenicalism";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 30:
                passion = "radical fundamentalist religion";
                INT[number] = (int)(3*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(3*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 31:
                passion = "gardening";
                INT[number] = (int)(4*Math.random()+2);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 32:
                passion = "cooking";
                INT[number] = 3;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 33:
                passion = "the Holocaust";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(4*Math.random()+2);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 34:
                passion = "conspiracy theories";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(4*Math.random()+2);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 35:
                passion = "browsing dank memes";
                INT[number] = (int)(3*Math.random()+1);
                STR[number] = (int)(3*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(3*Math.random()+1);
                break;
            case 36:
                passion = "programming";
                INT[number] = 5;
                STR[number] = (int)(4*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(4*Math.random()+1);
                break;
            case 37:
                passion = "reading";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 38:
                passion = "listening to music";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 39:
                passion = "murder";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 40:
                passion = "fishing";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 41:
                passion = "invading Russia in the winter";
                INT[number] = 0;
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 42:
                passion = "writing short stories";
                INT[number] = (int)(2*Math.random()+4);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 43:
                passion = "writing novels";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 44:
                passion = "watching cartoons";
                INT[number] = 2;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 2;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 45:
                passion = "watching movies";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(3*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(3*Math.random()+1);
                break;
            case 46:
                passion = "masochism";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 47:
                passion = "shopping";
                INT[number] = (int)(3*Math.random()+3);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 48:
                passion = "infanticide";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 49:
                passion = "regicide";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 50:
                passion = "traveling abroad";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 51:
                passion = "arson";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 52:
                passion = "math";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 53:
                passion = "science";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 54:
                passion = "teaching";
                INT[number] = 4;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 55:
                passion = "learning";
                INT[number] = 4;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 56:
                passion = "geology";
                INT[number] = 4;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 57:
                passion = "archeology";
                INT[number] = 4;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 58:
                passion = "horology";
                INT[number] = (int)(3*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 59:
                passion = "horoscopes";
                INT[number] = (int)(3*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 60:
                passion = "astronomy";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(3*Math.random()+3);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 61:
                passion = "astrology";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 62:
                passion = "physics";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 63:
                passion = "chemistry";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 64:
                passion = "biology";
                INT[number] = 4;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 65:
                passion = "quantum computing";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 66:
                passion = "statistics";
                INT[number] = 3;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 67:
                passion = "linguistics";
                INT[number] = (int)(4*Math.random()+2);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 68:
                passion = "history";
                INT[number] = (int)(3*Math.random()+3);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 69:
                passion = "government";
                INT[number] = 0;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 70:
                passion = "politics";
                INT[number] = 0;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(3*Math.random()+3);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 71:
                passion = "psychology";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 72:
                passion = "sociology";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 4;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 73:
                passion = "exercising";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 74:
                passion = "cosmetology";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 75:
                passion = "plastic surgery";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 76:
                passion = "dentistry";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 77:
                passion = "agriculture";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 78:
                passion = "baby Animals";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 79:
                passion = "beaches";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(3*Math.random()+3);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(3*Math.random()+3);
                break;
            case 80:
                passion = "The Beatles";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 81:
                passion = "music";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 82:
                passion = "clothing";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 83:
                passion = "pets";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(3*Math.random()+3);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 84:
                passion = "corgis";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(3*Math.random()+3);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 85:
                passion = "cats";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 86:
                passion = "dinosaurs";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 87:
                passion = "alligators";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 4;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 88:
                passion = "elephants";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 89:
                passion = "RNGesus";
                INT[number] = 5;
                STR[number] = 5;
                PRS[number] = 5;
                AGI[number] = 5;
                break;
            case 90:
                passion = "World of Warcraft";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 1;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 1;
                break;
            case 91:
                passion = "loot. Sweet, precious loot";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 1;
                break;
            case 92:
                passion = "mechanical keyboards";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 93:
                passion = "volunteering";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(2*Math.random()+4);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 94:
                passion = "donating to charity";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 95:
                passion = "Net Neutrality";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 96:
                passion = "Making America Great Again";
                INT[number] = 0;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(3*Math.random()+3);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 97:
                passion = "falafel";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 98:
                passion = "pyromancy";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 1;
                break;
            case 99:
                passion = "money";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 100:
                passion = "anarchy";
                INT[number] = (int)(2*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 3;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 101:
                passion = "being socially awkward";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 1;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 102:
                passion = "https://www.reddit.com/r/The_Donald/";
                INT[number] = 0;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 103:
                passion = "It’s Always Sunny in Philadelphia";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 104:
                passion = "the World Wide Web";
                INT[number] = (int)(3*Math.random()+3);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 105:
                passion = "one-upping your neighbor";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 1;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 106:
                passion = "cat GIFs";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 107:
                passion = "guns";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 108:
                passion = "germs";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 1;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 109:
                passion = "steel";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 110:
                passion = "prehistoric creatures";
                INT[number] = 4;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 111:
                passion = "unicellular organisms";
                INT[number] = (int)(3*Math.random()+3);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 112:
                passion = "the plague";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 113:
                passion = "education";
                INT[number] = 4;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 114:
                passion = "communism";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 115:
                passion = "democracy";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 116:
                passion = "overthrowing capitalism";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 117:
                passion = "festivals";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 118:
                passion = "Christmas";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 119:
                passion = "holidays";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 120:
                passion = "Satan";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 121:
                passion = "the Lord and Savior";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(4*Math.random()+2);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 122:
                passion = "Mao Zedong";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 123:
                passion = "Kim Jung Un";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 124:
                passion = "firefighters";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 4;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 125:
                passion = "fires";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 4;
                break;
            case 126:
                passion = "fights";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 127:
                passion = "fireflies";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 128:
                passion = "flies";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 0;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 129:
                passion = "African safaris";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 130:
                passion = "large cats";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 4;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 131:
                passion = "fireworks";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 132:
                passion = "arson";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = 5;
                break;
            case 133:
                passion = "homicide";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 134:
                passion = "legalism";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 135:
                passion = "flowers";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 136:
                passion = "pollen";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 137:
                passion = "BEES, THE BEES ARE DYING";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(4*Math.random()+2);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 138:
                passion = "grandparents";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(4*Math.random()+2);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 139:
                passion = "familial relations";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 140:
                passion = "familial relations ( ͡° ͜ʖ ͡°)";
                INT[number] = 0;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 141:
                passion = "( ͡° ͜ʖ ͡°)";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 142:
                passion = "filial piety";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 143:
                passion = "your family’s honor";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 144:
                passion = "destruction";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 145:
                passion = "viruses";
                INT[number] = 4;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 146:
                passion = "happiness";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 147:
                passion = "sadness";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 0;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 148:
                passion = "anger";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(4*Math.random()+2);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 149:
                passion = "teachings of Confucius";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 150:
                passion = "Karl Marx";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 151:
                passion = "the Communist Manifesto";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 152:
                passion = "Mein Kampf";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 153:
                passion = "The Lord of the Flies Beelzebub";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(4*Math.random()+2);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 154:
                passion = "worshiping Lucifer";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 155:
                passion = "the stock market";
                INT[number] = (int)(3*Math.random()+3);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 156:
                passion = "Harry Potter";
                INT[number] = (int)(2*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 157:
                passion = "The Lord of the Rings";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 158:
                passion = "Star Wars";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(2*Math.random()+4);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 159:
                passion = "Star Trek";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 160:
                passion = "learning useless talents";
                INT[number] = 2;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 161:
                passion = "Bitcoin";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 162:
                passion = "ice cream";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 163:
                passion = "freezing dead bodies";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 164:
                passion = "Pokemon Go";
                INT[number] = (int)(3*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 165:
                passion = "whittling";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 166:
                passion = "soap art";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 167:
                passion = "summoning Cthulhu";
                INT[number] = (int)(3*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(4*Math.random()+2);
                break;
            case 168:
                passion = "alcoholism";
                INT[number] = 0;
                STR[number] = (int)(2*Math.random());
                PRS[number] = (int)(2*Math.random());
                AGI[number] = (int)(2*Math.random());
                break;
            case 169:
                passion = "cocaine";
                INT[number] = (int)(2*Math.random());
                STR[number] = (int)(2*Math.random());
                PRS[number] = (int)(2*Math.random());
                AGI[number] = (int)(2*Math.random());
                break;
            case 170:
                passion = "crack";
                INT[number] = (int)(2*Math.random());
                STR[number] = (int)(2*Math.random());
                PRS[number] = (int)(2*Math.random());
                AGI[number] = (int)(2*Math.random());
                break;
            case 171:
                passion = "heroin";
                INT[number] = (int)(2*Math.random());
                STR[number] = (int)(2*Math.random());
                PRS[number] = (int)(2*Math.random());
                AGI[number] = (int)(2*Math.random());
                break;
            case 172:
                passion = "marijuana";
                INT[number] = (int)(2*Math.random());
                STR[number] = (int)(2*Math.random());
                PRS[number] = (int)(2*Math.random());
                AGI[number] = (int)(2*Math.random());
                break;
            case 173:
                passion = "legalizing marijuana";
                INT[number] = (int)(3*Math.random()+1);
                STR[number] = (int)(3*Math.random()+1);
                PRS[number] = (int)(3*Math.random()+1);
                AGI[number] = (int)(3*Math.random()+1);
                break;
            case 174:
                passion = "butchery";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 175:
                passion = "sculpting";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(3*Math.random()+3);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 176:
                passion = "building large monuments";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 177:
                passion = "nature";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 178:
                passion = "movies";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 179:
                passion = "food";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 2;
                break;
            case 180:
                passion = "nonedible food";
                INT[number] = 0;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 181:
                passion = "edibles";
                INT[number] = (int)(2*Math.random());
                STR[number] = (int)(2*Math.random());
                PRS[number] = (int)(2*Math.random());
                AGI[number] = (int)(2*Math.random());
                break;
            case 182:
                passion = "pandas";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 183:
                passion = "Panda Express";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 1;
                break;
            case 184:
                passion = "Chinese food";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 185:
                passion = "dogs as food";
                INT[number] = (int)(4*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 0;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 186:
                passion = "dog food";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 187:
                passion = "PetSmart";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 188:
                passion = "cannibalism";
                INT[number] = 1;
                STR[number] = 5;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 189:
                passion = "beds";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 1;
                break;
            case 190:
                passion = "sleep";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 0;
                break;
            case 191:
                passion = "pizza";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 1;
                break;
            case 192:
                passion = "smiles";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(2*Math.random()+4);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 193:
                passion = "laughter";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(2*Math.random()+4);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 194:
                passion = "(s)laughter";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = 4;
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 195:
                passion = "sports";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(2*Math.random()+4);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 196:
                passion = "scoring goal units in sports";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(3*Math.random()+3);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 197:
                passion = "sugar";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(3*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(2*Math.random()+1);
                break;
            case 198:
                passion = "diabetes";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(3*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 0;
                break;
            case 199:
                passion = "the sun";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 200:
                passion = "dealing in absolutes (only a sith would)";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 201:
                passion = "having the high ground";
                INT[number] = 5;
                STR[number] = 5;
                PRS[number] = 5;
                AGI[number] = 5;
                break;
            case 202:
                passion = "going to random high school proms";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = 5;
                break;
            case 203:
                passion = "booty";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 204:
                passion = "pretending to be the Walmart greeter";
                INT[number] = 4;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 205:
                passion = "camping";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(3*Math.random()+3);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(3*Math.random()+3);
                break;
            case 206:
                passion = "Bob Marley";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(2*Math.random()+4);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 207:
                passion = "vacations";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 208:
                passion = "¯\\_(ツ)_/¯";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 209:
                passion = "white people";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 210:
                passion = "black people";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 211:
                passion = "Asian people";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 212:
                passion = "political prisoners";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 213:
                passion = "telling people you’re going to do something then not doing it";
                INT[number] = (int)(5*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = 5;
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 214:
                passion = "hummus";
                INT[number] = (int)(2*Math.random()+1);
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            case 215:
                passion = "Nicolas Cage";
                INT[number] = 5;
                STR[number] = 5;
                PRS[number] = 5;
                AGI[number] = 5;
                break;
            case 216:
                passion = "Phishing";
                INT[number] = 5;
                STR[number] = (int)(5*Math.random()+1);
                PRS[number] = (int)(5*Math.random()+1);
                AGI[number] = (int)(5*Math.random()+1);
                break;
            default :
                passion = "nothing. You lack all forms of drive.";
                INT[number] = 0;
                STR[number] = 0;
                PRS[number] = 0;
                AGI[number] = 0;
        }

        return passion;
    }
    public String activityGenerator(){
        String activity = "";
        int rollAct = (int)(77*Math.random()+1);
        activity = switchAct(rollAct);
        return activity;
    }
    public void calculateSum(){
        for(int i=0; i<INT.length; i++)
            TINT+=INT[i];
        for(int i=0; i<STR.length; i++)
            TSTR+=STR[i];
        for(int i=0; i<PRS.length; i++)
            TPRS+=PRS[i];
        for(int i=0; i<AGI.length; i++)
            TAGI+=AGI[i];
    }
    public String switchAct(int j){
        String action = "";
        result = "";
        calculateSum();
        switch(j) {
            case 1 :
                action = "overthrow the bourgeoisie";
                if(TSTR > 8 && TPRS > 9) {
                    result = "Congratulations! The Proletarian Revolution has succeeded!";
                }
                else {
                    result = "The revolution has failed.";
                    isAlive = false;
                }
                break;
            case 2 :
                action = "just end it all";
                result = "You just ended it all.";
                isAlive = false;
                break;

            case 3 :
                action = "burn down a forest";
                if(TAGI> 6 && TSTR > 5) {
                    result = "You started a forest fire. Smokey is disappointed in you.";
                }
                else {
                    result = "You failed to start a forest fire.";
                }
                break;
            case 4 :
                action = "reintroduce the black plague to the world";
                if(TINT > 10 && TPRS > 8) {
                    result = "The black plague kills millions. Hope you're happy.";
                }
                else {
                    result = "You failed to reintroduce the plague.";
                }
                break;
            case 5 :
                action = "climb Mount Everest";
                if(TSTR > 6 && TAGI > 9) {
                    result = "You successfully climbed Mt. Everest and only lost two Sherpas!";
                }
                else {
                    result = "You died on the cold, barren slopes of Everest.";
                    isAlive = false;
                }
                break;
            case 6 :
                action = "take a safari trip in Africa";
                if(TINT > 4 && TAGI > 4) {
                    result = "You enjoyed the safari and didn't get mauled!";
                }
                else {
                    result = "You got mauled by lions in the African savannah.";
                    isAlive = false;
                }
                break;
            case 7 :
                action = "go for a bike ride";
                if(TAGI > 3 && TSTR > 2 && TINT > 5) {
                    result = "You enjoyed a nice bike ride.";
                }
                else if(TINT <= 5) {
                    result = "You don't know how to ride a bike.";
                }
                else {
                    result = "You got hit by a car.";
                    isAlive = false;
                }
                break;
            case 8 :
                action = "take piloting lessons";
                if(TINT > 10 && TPRS > 4) {
                    result = "You successfully learned how to fly a plane.";
                }
                else {
                    result = "You crashed on your first flight into a kid's birthday party.";
                    isAlive = false;
                }
                break;
            case 9 :
                action = "chug bleach";
                if(TINT > 4) {
                    result = "You drank bleach and died.";
                    isAlive = false;
                }
                else {
                    result = "You were too stupid to drink the bleach and suffered chemical burns on your face.";
                }
                break;
            case 10 :
                action = "fly to Mars";
                if(TINT > 12 && TPRS > 6) {
                    result = "You managed to get to Mars somehow. Hope you don't get left behind like Matt Damon.";
                }
                else {
                    result = "Your spaceship blew up on launch and you died.";
                    isAlive = false;
                }
                break;
            case 11 :
                action = "plant a tree";
                if(TINT > 3 && TAGI > 4) {
                    result = "You planted a tree. Tree hugger.";
                }
                else {
                    result = "You somehow messed up planting a tree and instead buried yourself alive.";
                    isAlive = false;
                }
                break;
            case 12 :
                action = "donate to the homeless";
                if (TINT > 3 && TSTR > 2) {
                    result = "You gave the homeless. What a good person you are.";
                }
                else {
                    result = "You didn't donate to the homeless. They don't deserve anything anyway.";
                }
                break;
            case 13 :
                action = "vote for a Republican";
                if(TINT > 7) {
                    result = "You elected a Republican.";
                }
                else {
                    result = "You messed up, and Jill Stein is now president.";
                }
                break;
            case 14 :
                action = "vote for a Democrat";
                if(TINT > 7) {
                    result = "You elected a Democrat.";
                }
                else {
                    result = "You messed up, and Jill Stein is now president.";
                }
                break;
            case 15 :
                action = "vote for Gary Johnson";
                if(TINT > 11) {
                    result = "You elected Gary Johnson.";
                }
                else {
                    result = "You messed up and became the next libertarian candidate for president.";
                }
                break;
            case 16 :
                action = "build a bear at Build-A-Bear Workshop";
                if(TINT > 3 && TAGI > 4) {
                    result = "You made a cute bear.";
                }
                else {
                    result = "You stole a little girl's bear and made her cry, you monster.";
                }
                break;
            case 17 :
                action = "befriend an octopus";
                if(TPRS > 10 && TINT > 6 && TAGI > 5) {
                    result = "You successfully befriended an octopus.";
                }
                else {
                    result = "The octopus dislikes you and eats you.";
                    isAlive = false;
                }
                break;
            case 18 :
                action = "adopt a dog";
                if(TINT > 7) {
                    result = "You successfully adopted a dog.";
                }
                else {
                    result = "You tried to adopt a bear, and it didn't end well.";
                    isAlive = false;
                }
                break;
            case 19 :
                action = "adopt a cat";
                if(TINT > 7) {
                    result = "You successfully adopted a cat.";
                }
                else {
                    result  = "You tried to adopt a lion, and it didn't end well.";
                    isAlive = false;
                }
                break;
            case 20 :
                action = "adopt a bird";
                if(TINT > 7) {
                    result = "You successfully adopted a bird.";
                }
                else {
                    result = "You tried to adopt an emu, and it didn't end well.";
                    isAlive = false;
                }
                break;
            case 21 :
                action = "adopt a fish";
                if(TINT > 7) {
                    result = "You successfully adopted a fish.";
                }
                else {
                    result = "You tried to adopt a shark, and it didn't end well.";
                    isAlive = false;
                }
                break;
            case 22 :
                action = "adopt a hamster";
                if(TINT > 7) {
                    result = "You successfully adopted a hamster.";
                }
                else {
                    result = "You tried to adopt a rabid raccoon, and it didn't end well.";
                    isAlive = false;
                }
                break;
            case 23 :
                action = "adopt a rabbit";
                if(TINT > 7) {
                    result = "You successfully adopted a rabbit.";
                }
                else {
                    result = "You tried to adopt a ferret, and it didn't end well.";
                    isAlive = false;
                }
                break;
            case 24 :
                action = "adopt a fox";
                if(TINT > 8) {
                    result = "You successfully adopted a fox.";
                }
                else {
                    result = "You tried to adopt a wolf, and it didn't end well.";
                    isAlive = false;
                }
                break;
            case 25 :
                action = "adopt an elephant";
                if(TINT > 9) {
                    result = "You successfully adopted an elephant.";
                }
                else {
                    result = "The elephant trampled you to death.";
                    isAlive = false;
                }
                break;
            case 26 :
                action = "adopt a child from Africa who has tuberculosis";
                if(TINT > 5 && TPRS > 8) {
                    result = "You adopted a sick child, who died two days after reaching the US.";
                }
                else {
                    result = "Adoption services turned you down. You got tuberculosis anyways.";
                    isAlive = false;
                }
                break;
            case 27 :
                action = "adopt the president’s child you are about to orphan";
                if(TINT > 9 && TSTR > 10 && TAGI > 10 && TPRS > 11) {
                    result = "You successfully kidnapped the child and now plot to assassinate the president.";
                }
                else {
                    result = "The Secret Service killed you a few meters from the White House gate.";
                    isAlive = false;
                }
                break;
            case 28 :
                action = "assassinate the president";
                if(TINT > 13 && TAGI > 10 && TPRS > 10) {
                    result = "You successfully assassinated the president as he was riding in his limo.";
                }
                else {
                    result = "You failed; you shot one Secret Service agent before being killed.";
                    isAlive = false;
                }
                break;
            case 29 :
                action = "go for a drive";
                if(TINT > 5 && TAGI > 6) {
                    result = "You enjoyed a lovely afternoon drive.";
                }
                else {
                    result = "You wrapped your car around a tree.";
                    isAlive = false;
                }
                break;
            case 30 :
                action = "chill at the lake";
                if(TPRS > 3 && TAGI > 5) {
                    result = "You enjoyed a lovely day at the lake.";
                }
                else {
                    result = "You drowned in the lake.";
                    isAlive = false;
                }
                break;
            case 31 :
                action = "go golfing";
                if(TAGI > 6 && TSTR > 4) {
                    result = "You enjoyed a nice afternoon of golf.";
                }
                else {
                    result = "Fore! You get hit in the head by a ball.";
                    isAlive = false;
                }
                break;
            case 32 :
                action = "play a game of basketball";
                if(TSTR > 6 && TAGI > 8) {
                    result = "You enjoy a nice game of basketball.";
                }
                else {
                    result = "You get shot on your way to the basketball court.";
                    isAlive = false;
                }
                break;
            case 33 :
                action = "dunk on LeBron James";
                if(TAGI > 12 && TSTR > 12 && TINT > 8) {
                    result = "You dunked on LeBron James and instantly get offered an NBA contract.";
                }
                else {
                    result = "You don't dunk on Lebron. No one expected you to anyway.";
                }
                break;
            case 34 :
                action = "exercise";
                if(TSTR > 4 && TAGI > 5) {
                    result = "You shed some pounds and get fit. Congratulations.";
                }
                else {
                    result = "You are unable to exercise and rapidly become morbidly obese.";
                }
                break;
            case 35 :
                action = "start a diet";
                if(TINT > 5 && TPRS > 7) {
                    result = "You start a diet and get in shape!";
                }
                else {
                    result = "You quickly give in to your primal urges for pizza and ice cream.";
                }
                break;
            case 36 :
                action = "learn to cook something new";
                if(TINT > 5 && TAGI > 6) {
                    result = "You cook a delicious homemade meal for all your friends and family.";
                }
                else {
                    result = "Your kitchen catches on fire and you give food poisoning to your whole family.";
                }
                break;
            case 37 :
                action = "learn to cook Hitler’s secret recipe";
                if(TINT > 11 && TPRS > 10 && TSTR > 10) {
                    result = "You discover Hitler's secret recipe and catch the Jews.";
                }
                else {
                    result = "The liberals and Jews overthrow your government and you were forced to commit suicide.";
                    isAlive = false;
                }
                break;
            case 38 :
                action = "paint your room a different color";
                if(TINT > 4 && TAGI > 5) {
                    result = "You paint your room a beautiful shade of maroon.";
                }
                else {
                    result = "Your room looks like a Jackson Pollock painting.";
                }
                break;
            case 39 :
                action = "plan a trip out of the country";
                if(TINT > 5 && TPRS > 10) {
                    result = "You successfully travel to beautiful Italy and have a great time.";
                }
                else {
                    result = "You contract many foreign diseases and die a painful death.";
                    isAlive = false;
                }
                break;
            case 40 :
                action = "plan a trip out of your room. You never get out you sad, lonely piece of crap.";
                if(TINT > 13 && TSTR > 10 && TPRS > 12 && TAGI > 8) {
                    result = "You successfully leave your room for the first time in years. The sunlight burns and you quickly return inside.";
                }
                else {
                    result = "You collapse on the stairs and mummy has to drag you back to your computer.";
                }
                break;
            case 41 :
                action = "go for a jog";
                if(TSTR > 6 && TAGI > 7) {
                    result = "You successfully jog around the neighborhood in short shorts.";
                }
                else {
                    result = "You get shot jogging through the wrong part of town.";
                    isAlive = false;
                }
                break;
            case 42 :
                action = "swim laps";
                if(TSTR > 7 && TAGI > 8) {
                    result = "You swim many laps in the local pool, impressing the grannies doing water aerobics.";
                }
                else {
                    result = "You drown in the shallow end.";
                    isAlive = false;
                }
                break;
            case 43 :
                action = "open a barber shop";
                if(TINT > 6 && TPRS > 6) {
                    result = "You successfully open a local barber shop and cut many hairs.";
                }
                else {
                    result = "Your barber shop gets burnt down by the KKK.";
                    isAlive = false;
                }
                break;
            case 44 :
                action = "learn to juggle";
                if(TINT > 7 && TAGI > 10) {
                    result = "You can now juggle flaming chainsaws for multiple days straight.";
                }
                else {
                    result = "You get laughed off the stage at the local talent show.";
                }
                break;
            case 45 :
                action = "have a terrible knife juggling accident";
                result = "You bleed out and die after a terrible knife juggling accident.";
                isAlive = false;
                break;
            case 46 :
                action = "resurrect Vladimir Lenin";
                if(TINT > 10 && TPRS > 10) {
                    result = "Lenin returns from the afterlife and sets out to give socialism to the world.";
                }
                else {
                    result = "Putin prevents you from resurrecting Lenina and sends you to Siberia.";
                    isAlive = false;
                }
                break;
            case 47 :
                action = "science the heck out of something";
                if(TINT > 7 && TPRS > 4) {
                    result = "You science something real good.";
                }
                else {
                    result = "You fail to do any hecking science.";
                }
                break;
            case 48 :
                action = "learn a useful talent";
                if(TINT > 6 && TSTR > 4 && TPRS > 5 && TAGI > 4) {
                    result = "You learn how to do something useful.";
                }
                else {
                    result = "You procastinate and learn nothing.";
                }
                break;
            case 49 :
                action = "execute Order 66";
                if(TINT > 12 && TPRS > 12) {
                    result = "Once more the Sith shall rule the galaxy. And, we shall have peace.";
                }
                else {
                    result = "You are under arrest, Chancellor. The oppression of the Sith will never return. You have lost.";
                }
                break;
            case 50 :
                action = "commence the Proletariat Revolution";
                if(TINT > 7 && TPRS > 9 && TSTR > 6) {
                    result = "The dicatorship of the proletariat has been established.";
                }
                else {
                    result = "The monarchy remains intact, and the revolution has failed.";
                    isAlive = false;
                }
                break;
            case 51 :
                action = "contract Tuberculosis";
                result = "You successfully contract tuberculosis and are in great pain.";
                isAlive = false;
                break;
            case 52 :
                action = "create anarchy in the world";
                if(TINT > 8 && TPRS > 7) {
                    result = "Governments fall, and people are liberated. Anarchy spreads.";
                }
                else {
                    result = "You are jailed for attempting to overthrow the local county government.";
                }
                break;
            case 53 :
                action = "take over a remote country in Asia and start a dictatorship";
                if(TINT > 7 && TPRS > 8 && TSTR > 4) {
                    result = "You establish your own dictatorship and oppress many people for your own pleasure.";
                }
                else {
                    result = "A military coup ejects your government two days after its establishment, and you are publicly executed.";
                    isAlive = false;
                }
                break;
            case 54 :
                action = "build the Death Star";
                if(TINT > 10 && TPRS > 8 && TSTR > 4) {
                    result = "Fear with keep them in line. Fear of this battlestation.";
                }
                else {
                    result = "The rebel scum destroy your battlestation with only a few snub fighters.";
                    isAlive = false;
                }
                break;
            case 55 :
                action = "build the Death Star II";
                if(TINT > 10 && TPRS > 8 && TSTR > 4) {
                    result = "We are quite safe from your pitiful little band.";
                }
                else {
                    result = "Your overconfidence is your weakness. The rebels destroy your battlestation, again.";
                    isAlive = false;
                }
                break;
            case 56 :
                action = "overthrow capitalism";
                if(TINT > 8 && TPRS > 7) {
                    result = "The capitalist pigs are overthrown and communism is established.";
                }
                else {
                    result = "The capitalist pigs resist your revolt, and you are imprisoned for treaon.";
                }
                break;
            case 57 :
                action = "commit arson";
                if(TAGI > 8 && TSTR > 5) {
                    result = "You successfully light the local fire station on fire.";
                }
                else {
                    result = "You accidentally spill gasoline on yourself and burn alive.";
                    isAlive = false;
                }
                break;
            case 58 :
                action = "commit vehicular manslaughter";
                if(TSTR > 7 && TINT > 6) {
                    result = "You successfully hit and kill someone with your car.";
                }
                else {
                    result = "You are unable to hit someone with your car, fortunately for everyone else.";
                }
                break;
            case 59 :
                action = "learn how to cook";
                if(TINT > 5 && TAGI > 8) {
                    result = "You cook a wonderful meal for your family.";
                }
                else {
                    result = "You burn down your house trying to make hot pockets.";
                    isAlive = false;
                }
                break;
            case 60 :
                action = "learn how to cook human flesh";
                if(TSTR > 8 && TPRS > 7) {
                    result = "You cook and enjoy some high-quality human flesh.";
                }
                else {
                    result = "You eat human flesh raw and get a parasite and die.";
                    isAlive = false;
                }
                break;
            case 61 :
                action = "execute Louis XVI";
                if(TPRS > 9 && TSTR > 5) {
                    result = "You successfully end the French monarchy.";
                }
                else {
                    result = "You fail, and the monarchy lives on.";
                    isAlive = false;
                }
                break;
            case 62 :
                action = "start another French Revolution";
                if(TINT > 7 && TPRS > 9) {
                    result = "You successfully launch another revolution to restore the French monarchy.";
                }
                else {
                    result = "You fail to overthrow the French republic, and are jailed for treason.";
                }
                break;
            case 63 :
                action = "overthrow the British monarchy";
                if(TINT > 8 && TPRS > 10 && TSTR > 4) {
                    result = "You successfully end the already-useless British monarchy.";
                }
                else {
                    result = "You fail, and Queen Elizabeth II outlives you.";
                    isAlive = false;
                }
                break;
            case 64 :
                action = "learn a new language";
                if(TINT > 6 && TAGI > 3) {
                    result = "You successfully learn Klingon.";
                }
                else {
                    result = "You fail to learn any language, not even HTML.";
                }
                break;
            case 65 :
                action = "make a new friend";
                if(TPRS > 9 && TAGI > 4) {
                    result = "You make a new friend for life.";
                }
                else {
                    result = "You fail to make any friends, but make many new enemies.";
                }
                break;
            case 66 :
                action = "alienate all your friends and live alone for the rest of your life";
                result = "You successfully abandon your friends and live a lonely life.";
                break;
            case 67 :
                action = "forsake all human interaction and live in a bus in Alaska";
                if(TPRS > 6 && TAGI > 9) {
                    result = "You successfully live on a bus in Alaska, alone.";
                }
                else {
                    result = "You get mauled by bears.";
                    isAlive = false;
                }
                break;
            case 68 :
                action = "pester your friends until they collectively decide to kill you";
                if(TPRS > 7) {
                    result = "Your friends kill you.";
                    isAlive = false;
                }
                else {
                    result = "You don't have any friends to start with, so you live.";
                }
                break;
            case 69 :
                action = "get food poisoning";
                if(TAGI > 4) {
                    result = "You successfully get food poisoning and have a really awful week.";
                }
                else {
                    result = "You don't get food poisoning, because you never eat anything besides chicken tendies.";
                }
                break;
            case 70 :
                action = "find out about somebody’s allergies";
                if(TINT > 5 && TPRS > 4) {
                    result = "You learn of a friend's allergies because they tell you. You plot to poison them next time.";
                }
                else {
                    result = "You accidentally give your friend whatever they are allergic to and they die.";
                }
                break;
            case 71 :
                action = "give someone an allergic reaction";
                if(TINT > 5 && TPRS > 6) {
                    result = "You successfully give someone a life-threatening allergic reaction. Way to go!";
                }
                else {
                    result = "You try to give someone a reaction, but you are allergic to it as well, and go into a coma.";
                }
                break;
            case 72 :
                action = "change your sexual orientation";
                if(TINT > 5 && TPRS > 9) {
                    result = "You successfully become attracted to anything that moves.";
                }
                else {
                    result = "You are stuck in your current orientation. What a tragedy.";
                }
                break;
            case 73 :
                action = "change your gender";
                if(TINT > 5 && TPRS > 10) {
                    result = "You successfully become an Apache Attack Helicopter";
                }
                else {
                    result = "You accidentally castrate yourself.";
                }
                break;
            case 74 :
                action = "make dank memes";
                if(TINT > 2) {
                    result = "You post the dankest memes the Internet has ever seen.";
                }
                else {
                    result = "Your memes are rejected and forgotten.";
                }
                break;
            case 75 :
                action = "put the laughter in slaughter";
                if(TINT > 6 && TPRS > 6 && TAGI > 4) {
                    result = "You gleefully slaughter some younglings.";
                }
                else {
                    result = "You make people laugh instead of hurting them.";
                }
                break;
            case 76 :
                action = "pretend to be the Walmart greeter";
                if(TINT > 4 && TAGI > 3) {
                    result = "You successfully masquerade as a friendly old Walmart greeter for some reason.";
                }
                else {
                    result = "You are arrested for trespassing.";
                }
                break;
            case 77 :
                action = "tell people you’re going to do something then not doing it";
                if(TPRS > 9 && TINT > 3) {
                    result = "You succeesfully bluff your way into doing nothing.";
                }
                else {
                    result = "Everyone sees through your lies and laughs at you.";
                }
                break;
            default :
                action = "Absolutely nothing happens.";
                result = "Absolutely nothing happens.";

        }
        return action;
    }


    public void reset(){
        TINT = 0; //Total Stat
        TSTR = 0;
        TPRS = 0;
        TAGI = 0;
        isAlive = true;
    }

    public void generate(View view){
        reset();
        TextView textViewName = (TextView)findViewById(R.id.textViewName);
        String name = nameGenerator();
        textViewName.setText("Your name is now: " + name);
        textViewName.setVisibility(View.VISIBLE);
        TextView textViewSS2 = (TextView)findViewById(R.id.textViewSS2);
        String ssn = ssnGenerator();
        textViewSS2.setText(ssn);
        textViewSS2.setVisibility(View.VISIBLE);
        TextView textView2 = (TextView)findViewById(R.id.intstat);
        passion1 = passionGenerator(0);
        textView2.setText(passion1);
        textView2.setVisibility(View.VISIBLE);
        TextView textView3 = (TextView)findViewById(R.id.strstat);
        do{
            passion2 = passionGenerator(1);
        }while(passion2.equals(passion1));
        textView3.setText(passion2);
        textView3.setVisibility(View.VISIBLE);
        TextView textView4 = (TextView)findViewById(R.id.prsstat);
        do{
            passion3 = passionGenerator(2);
        }while(passion3.equals(passion1)||passion3.equals(passion2));
        textView4.setText(passion3);
        textView4.setVisibility(View.VISIBLE);
        TextView textView6 = (TextView)findViewById(R.id.textView6);
        act1 = activityGenerator();
        textView6.setText(act1);
        textView6.setVisibility(View.VISIBLE);
        activateButton = true;
        Button button = (Button)findViewById(R.id.button);
        button.setVisibility(View.VISIBLE);
    }
    public void sendMessage(View view){
        if(!activateButton)
            return;
        Intent intent = new Intent(this, PointBreakdown.class);
        intent.putExtra("INT", INT);
        intent.putExtra("STR", STR);
        intent.putExtra("PRS", PRS);
        intent.putExtra("AGI", AGI);
        intent.putExtra("passion1", passion1);
        intent.putExtra("passion2", passion2);
        intent.putExtra("passion3", passion3);
        intent.putExtra("result", result);
        intent.putExtra("TINT", TINT);
        intent.putExtra("TSTR", TSTR);
        intent.putExtra("TPRS", TPRS);
        intent.putExtra("TAGI", TAGI);
        intent.putExtra("isAlive", isAlive);
        startActivity(intent);
    }
}
