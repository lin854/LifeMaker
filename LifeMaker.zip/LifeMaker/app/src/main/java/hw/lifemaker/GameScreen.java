package hw.lifemaker;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class GameScreen extends AppCompatActivity {
    public int TINT; //Total stat value
    public int TSTR;
    public int TPRS;
    public int TAGI;
    public String act1;
    public String result;
    public boolean isAlive;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_screen);
        Intent intent = getIntent();
        TINT = intent.getIntExtra("TINT", 0);
        TSTR = intent.getIntExtra("TSTR", 0);
        TPRS = intent.getIntExtra("TPRS", 0);
        TAGI = intent.getIntExtra("TAGI", 0);
        isAlive = intent.getBooleanExtra("isAlive", true);
        act1 = intent.getStringExtra("act1");
        result = intent.getStringExtra("result");
        TextView intstat = (TextView)findViewById(R.id.intstat);
        intstat.setText("Intelligence (INT) = "+TINT);
        TextView strstat = (TextView)findViewById(R.id.strstat);
        strstat.setText("Strength (STR) = "+TSTR);
        TextView prsstat = (TextView)findViewById(R.id.prsstat);
        prsstat.setText("Persuasiveness (PRS) = "+TPRS);
        TextView agistat = (TextView)findViewById(R.id.agistat);
        agistat.setText("Agility (AGI) = "+TAGI);
        TextView result = (TextView)findViewById(R.id.res);
        result.setText(intent.getStringExtra("result"));
        TextView mortality = (TextView)findViewById(R.id.mortality);
        if(isAlive)
            mortality.setText("Regardless of what happened, you've managed to survive another day... Good for you.");
        else
            mortality.setText("RNGesus prepared a cruel fate for you, for you have died! How you even managed to do so is beyond us.");
    }
    public void toCredits(View view){
        Intent intent = new Intent(this, Credits.class);
        startActivity(intent);
    }
}